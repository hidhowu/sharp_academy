<?php
// Start the session
session_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Check if the user session is active and the user role is 'admin'
if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin') {
    // User session is active and user role is 'admin'
    // Perform actions for authorized users here

    // Example: Display a welcome message
    // echo "Welcome, Admin!";


include '../includes/db.php';
include '../includes/functions.php';
if(isset($_POST['title'], $_POST['content'])){


require '../vendor/autoload.php';

$tracker = bin2hex(random_bytes(16));
    $subject = $_POST['title'];
    $message = $_POST['content'];


    // echo $title. '<br><br><br>';
    
    $message = str_replace("'", "\"", $message);
    // echo $message;


    $message = '<img src="https://sharpacademy.io/tracker.php?code="'.$tracker.'" alt="Tracker" style="width: 0; height: 0; display: none;" /> '.$message;
// Prepare the insert statement
$sql = "INSERT INTO stat (title, tracker) VALUES (?, ?)";
$params = [$subject, $tracker];

// Execute the prepared query using prepared_query()
$stmt = prepared_query($conn, $sql, $params);

// Check if the insert was successful
if ($stmt->affected_rows > 0) {
    // echo "Statistics Data insert successful! <br>";
} else {
    echo "Statistics Data Insert failed or Duplicate Data! <br>";
}

// Close the statement and the database connection
// $stmt->close();
// $conn->close();


$mail = new PHPMailer(true);

  //Server settings
  $mail->SMTPDebug = 0;                      //Enable verbose debug output
  $mail->isSMTP();                                            //Send using SMTP
  $mail->Host       = 'email-smtp.us-east-1.amazonaws.com';                     //Set the SMTP server to send through
  $mail->Port       = 465;  //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
  $mail->SMTPSecure =  'ssl';            //Enable implicit TLS encryption
  $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
  $mail->Username   = 'AKIATXV2AGR2XCDUEECW';                     //SMTP username
  $mail->Password   = 'BOyeduCayXx9tQ1VmJ3eZ8JyRBjEox0dcaG/bDQwSMEw';                               //SMTP password

    //Recipients
    $mail->setFrom('247@sharpacademy.io', 'Sharp247');
    // $mail->addAddress('ellen@example.com');               //Name is optional
    $mail->addReplyTo('247@sharpacademy.io', 'Sharp247');

    //Content
    $mail->isHTML(true);                                  //Set email format to HTML



    // Increase the maximum execution time (adjust as needed)
set_time_limit(0);

// Define your email sending function
function sendEmail($mail, $conn, $recipient, $subject, $message) {
    
    try {
  
        // //Server settings
        // $mail->SMTPDebug = 0;                      //Enable verbose debug output
        // $mail->isSMTP();                                            //Send using SMTP
        // $mail->Host       = 'email-smtp.us-east-1.amazonaws.com';                     //Set the SMTP server to send through
        // $mail->Port       = 465;  //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
        // $mail->SMTPSecure =  'ssl';            //Enable implicit TLS encryption
        // $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
        // $mail->Username   = 'AKIATXV2AGR2XCDUEECW';                     //SMTP username
        // $mail->Password   = 'BOyeduCayXx9tQ1VmJ3eZ8JyRBjEox0dcaG/bDQwSMEw';                               //SMTP password
    
        // //Recipients
        // $mail->setFrom('247@sharpacademy.io', 'Sharp247');
        // // $mail->addAddress('ellen@example.com');               //Name is optional
        // $mail->addReplyTo('247@sharpacademy.io', 'Sharp247');
        
        // //Content
        // $mail->isHTML(true);                                  //Set email format to HTML
        $mail->addAddress($recipient);     //Add a recipient
        $mail->Subject = $subject;
      
        $mail->Body = $message;
        // $mail->AltBody = '';
    
        $mail->send();


          // Prepare the update statement
          $sql = "UPDATE stat SET sent = sent + 1 WHERE title = ?"; // Replace <condition> with the appropriate condition

          // Execute the prepared query using prepared_query()
          $stmt = prepared_query($conn, $sql, [$subject]);
  
          // Check if the update was successful
          if ($stmt->affected_rows > 0) {
            //   echo "Update Statistics Data successful! <br>";
          } else {
              echo "Update Statistics Data failed  <br>";
          }
  
        // echo 'Message has been sent';
        // echo 'success';

    } catch (Exception $e) {
        // echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        echo 'Message Sending failed (Email: '.$recipient.') <br>';
    }
}

        // Define your email list and parameters
        $emails = [];

        // Prepare the select statement
        $sqlt = "SELECT email FROM members";

        // Execute the query
        $result = mysqli_query($conn, $sqlt);

        // Check if the query execution was successful
        if ($result) {
        // Create an empty array to store the emails
        $emails = [];

        // Fetch the result and store emails in the array
        while ($row = mysqli_fetch_assoc($result)) {
        $emails[] = $row['email'];
        }

        // Free the result set
        mysqli_free_result($result);

        // Print the emails or use them as needed
        // print_r($emails);
        } else {
        // Query execution failed
        echo "Email List Selection Failed";
        }

        // Close the database connection
        // mysqli_close($conn);


// print_r($emails);



// $emails = array(
//     array('recipient1@example.com', 'Subject 1', 'Message 1'),
//     array('recipient2@example.com', 'Subject 2', 'Message 2'),
//     // Add more email entries here as needed
// );

$batchSize = 30; // Number of emails to send in each batch
$delaySeconds = 1; // Delay in seconds between batches

$totalEmails = count($emails);
$currentEmailIndex = 0;

while ($currentEmailIndex < $totalEmails) {
    // Send emails in batches
    $batchEmails = array_slice($emails, $currentEmailIndex, $batchSize);
    // print_r($batchEmails);

    foreach ($batchEmails as $email) {
       $recipient = $email;
       

        // Send the email
        sendEmail($mail, $conn, $recipient, $subject, $message);

      
        // Close the statement and the database connection
        // $stmt->close();
        // $conn->close();
    }

    // Delay between batches
    sleep($delaySeconds);

    // Update the current email index
    $currentEmailIndex += $batchSize;
}
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="robots" content="noindex">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.7/dist/tailwind.min.css">
    <title>Mail Sender</title>
</head>
<body class="bg-gray-100">
    <div class="mt-10 flex justify-center" id="">

        <a href="index.php"  id=""
                class="bg-gray-500  ml-5 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded">
            Back to Dashboard
        </a>
    </div>
    <div class="container mx-auto py-10">
        <h1 class="text-3xl text-center font-bold mb-6">Email Publisher</h1>
        <form action="" method="post" class="lg:w-9/12 w-full mx-auto bg-white p-8 rounded shadow-md">
            <div class="mb-6">
                <label for="title" class="block text-gray-700 font-medium mb-2">Title:</label>
                <input type="text" id="title" name="title" required
                       class="w-full p-2 border border-gray-300 rounded focus:outline-none focus:border-blue-500">
            </div>

            <div class="mb-6">
                <label for="content" class="block text-gray-700 font-medium mb-2">Content (Email Body):</label>
                <textarea id="content" name="content" rows="26" required
                          class="w-full p-2 border border-gray-300 rounded focus:outline-none focus:border-blue-500"></textarea>
            </div>

            <button  id="preview"
                    class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded">
                Preview
            </button>
            <button type="submit" name="publish"
                    class="bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded">
                Publish
            </button>
        </form>
    </div>
    <div class="fixed w-screen h-screen bg-gray-100 overflow-auto" id="prev">
        <button class="p-10" id="close">Close Preview</button>
        <div class="lg:flex lg:justify-between flex-wrap" id="">

            <div class="" id="preview-container">
    
            </div>
    
            
           
        </div>
    </div>
</body>
<script>
const previewMail = function(){
    const container = document.getElementById('preview-container');
    const mobile = document.getElementById('mobile');
    const prev = document.getElementById('prev');
    const inputed = document.getElementById('content').value;

    container.innerHTML = inputed;
    mobile.innerHTML = inputed;
    prev.classList.add('top-0', 'left-0');

}


const closePrev = ()=>prev.classList.remove('top-0', 'left-0');

document.getElementById('close').addEventListener("click", closePrev);




    document.getElementById('preview').addEventListener("click", previewMail);
</script>
</html>
<?php
} else {
    // User session is not active or user role is not 'admin'
    // Redirect to the login page or perform any other action
    header("Location: login.php");
    exit();
}
?>